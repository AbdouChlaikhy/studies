<%@page import="java.sql.*" %>
<%!int m;%>
<%!String n;%>
<%!float s;%>
<%!float p;%>

<%
  m=Integer.parseInt(request.getParameter("m"));
  n=request.getParameter("n");
  s=Float.valueOf(request.getParameter("s"));
  p=Float.valueOf(request.getParameter("p"));
  
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection co=null;
co=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","marah");
Statement s1=co.createStatement();

String req="insert into personne values("+m+",'"+n+"',"+s+","+p+")";

int res=s1.executeUpdate(req);
    
}

catch(ClassNotFoundException e1)
{
    out.println("err pilote");
    
}

catch(SQLException e2)
{
    out.println("err requete");
}





%>