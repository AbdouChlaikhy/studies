<%-- 
    Document   : jspsaisie
    Created on : 10 mars 2024, 15:50:13
    Author     : pc
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <form action ="calcul.jsp" method="post">
    <center>
        valeur 1
        <input type="text" name="v1"><br><br>
        valeur 2
        <input type="text" name="v2"><br><br><br>
        
        
        <input type="submit" value="Somme">
        
        
    </center>
        </form>
    </body>
</html>
