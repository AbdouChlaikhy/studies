<%-- 
    Document   : jspsaisiebd
    Created on : 10 mars 2024, 16:36:32
    Author     : pc
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
    <center>
        <form action="ajout.jsp" method="post">
        
        Matricule
        <input type="text" name="m"><br><br>
        
        Nom
        <input type="text" name="n"><br><br>
        
        Salaire
        <input type="text" name="s"><br><br>
        
        Prime
        <input type="text" name="p"><br><br>
        
        
        <input type="submit" value="Insertion"><br><br>
        
        </form>
    </center>
    </body>
</html>
