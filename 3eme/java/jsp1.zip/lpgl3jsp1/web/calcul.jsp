<%!float val1; %>
<%!float val2; %>


<%
  float cal=0;
val1=Float.valueOf(request.getParameter("v1"));
val2=Float.valueOf(request.getParameter("v2"));
cal=val1+val2;
out.println("la somme est : "+cal);

%>
