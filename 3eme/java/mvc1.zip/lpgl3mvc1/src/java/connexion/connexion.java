/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connexion;

/**
 *
 * @author pc
 */
import java.sql.*;
public class connexion {
    
    public static Connection con;
    public static Connection getConnection()
    {
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","marah");
            
        }
        catch(ClassNotFoundException e1)
        {
            System.out.println("err pilote");
        }
        catch(SQLException e2)
        {
            System.out.println("err : connexion");
        }
        return con;
    }
    public static void main(String[] arg)
    {
        getConnection();
        System.out.println("good connection ????????????");
    }
}
