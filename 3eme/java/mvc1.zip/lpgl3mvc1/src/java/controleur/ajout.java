/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

/**
 *
 * @author pc
 */
import java.sql.*;
public class ajout {
    
    public static void  insertion(modele.personne obj)
    {
       connexion.connexion.getConnection();
      try
      {
       PreparedStatement s=connexion.connexion.con.prepareStatement("insert into personne values(?,?,?,?)");
      s.setInt(1,obj.getMat());
      s.setString(2,obj.getNom());
      s.setFloat(3,obj.getSal());
      s.setFloat(4,obj.getPr());
      ResultSet res=s.executeQuery();
      }
      catch(SQLException dd)
      {
          System.out.println("err connexion");
      }
    }
    
    
    
}
