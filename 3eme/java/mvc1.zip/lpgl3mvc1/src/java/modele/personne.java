/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author pc
 */
public class personne {
    private int mat;
    private String nom;
    private float sal;
    private float pr;

    public int getMat() {
        return mat;
    }

    public void setMat(int mat) {
        this.mat = mat;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public float getSal() {
        return sal;
    }

    public void setSal(float sal) {
        this.sal = sal;
    }

    public float getPr() {
        return pr;
    }

    public void setPr(float pr) {
        this.pr = pr;
    }
    
    public personne()
    {
        
    }
    
    public personne(int m,String n,float s,float p)
    {
        mat=m;
        nom=n;
        sal=s;
        pr=p;
    }
}
