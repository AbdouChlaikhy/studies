<%-- 
    Document   : jsp2
    Created on : 17 mars 2024, 13:02:25
    Author     : pc
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
    <center>
        <form action="ajout.jsp" method="post">
            Matricule 
            <input type="text" name="mat"><br>
            Nom 
            <input type="text" name="nom"><br>
            M.generale
            <input type="text" name="mg"><br>
            
            
            
            <input type="submit" value="Ajout"><br>
            
            
        </form>
    </center>
    </body>
</html>
