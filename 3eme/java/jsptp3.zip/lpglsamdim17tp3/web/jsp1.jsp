<jsp:useBean id="obj" class="modele.etudiant" scope="session"></jsp:useBean>
<jsp:setProperty name="obj" property="mat"></jsp:setProperty>
<jsp:setProperty name="obj" property="nom"></jsp:setProperty>
<jsp:setProperty name="obj" property="mg"></jsp:setProperty>


<%
    
out.println("le matricule :"+obj.getMat());
out.println("<br>");
out.println("le nom :"+obj.getNom());
out.println("<br>");
out.println("la M.generale :"+obj.getMg());



%>