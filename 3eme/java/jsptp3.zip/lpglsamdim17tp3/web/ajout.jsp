<%@page import ="java.sql.*" %>
<jsp:useBean id="obj" class="modele.etudiant" scope="session"></jsp:useBean>
<jsp:setProperty name="obj" property="mat"></jsp:setProperty>
<jsp:setProperty name="obj" property="nom"></jsp:setProperty>
<jsp:setProperty name="obj" property="mg"></jsp:setProperty>

<%
  try
                    {
                        Class.forName("oracle.jdbc.driver.OracleDriver");
                        Connection co=null;
                        co=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","marah");
                        Statement s1 = co.createStatement();
                        String req="insert into etudiant values("+obj.getMat()+",'"+obj.getNom()+"',"+obj.getMg()+")";
                        int resu=s1.executeUpdate(req);
                        
                        ServletContext ct = request.getServletContext();
                        RequestDispatcher dis=ct.getRequestDispatcher("/jsp2.jsp");
                        dis.forward(request,response);
                        

                    }
  
catch(ClassNotFoundException e1)
{
out.println("err pilote");
}
catch(SQLException e2)
{
out.println("err connexion");
}
                   




%>