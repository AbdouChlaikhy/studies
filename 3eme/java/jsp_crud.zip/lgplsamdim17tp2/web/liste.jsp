<%@page import ="java.sql.*" %>
<html>
    <head><title>Liste des personnes</title></head>
    <body>
        <center>
            <h1>Liste des personnes</h1>
            
            <table border ="2">
                <tr>
                    <td>Matricule</td>
                    <td>Nom</td>
                    <td>S.base</td>
                    <td>Prime</td>
                    <td>Action 1</td>
                    <td>Action 2</td>
                </tr>
                
                <%
                    try
                    {
                        Class.forName("oracle.jdbc.driver.OracleDriver");
                        Connection co=null;
                        co=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","marah");
                        Statement s1 = co.createStatement();
                        String req="select * from personne";
                        ResultSet res=s1.executeQuery(req);
                        while(res.next())
                        {
                            %>
                            
                            <tr>
                                <td>
                                    <%=res.getInt("mat")%>
                                </td>
                                <td>
                                    <%=res.getString("nom")%>
                                </td>
                                <td>
                                    <%=res.getFloat("sal")%>
                                </td>
                                <td>
                                    <%=res.getFloat("pr")%>
                                </td>
           <td>
               <a href="formmodif.jsp?mat=<%=res.getInt("mat")%>">Update</a>
          </td>
          
          <td>
               <a href="sup.jsp?mat=<%=res.getInt("mat")%>">Suppression</a>
          </td>
                            </tr>
                            <%
                        }
                    }

catch(ClassNotFoundException e1)
{
out.println("err pilote");
}
catch(SQLException e2)
{
out.println("err connexion");
}
                %>
                
                
                    </table>
                <br>
                <form action="ajout.jsp" method="post">
                    <input type="submit" value="New Person">
                </form>
                
        </center>
    </body>
</html>