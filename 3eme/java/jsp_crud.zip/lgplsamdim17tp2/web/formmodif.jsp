<%@page import="java.sql.*" %>

<%
    int mat=Integer.parseInt(request.getParameter("mat"));
    
try
                    {
                        Class.forName("oracle.jdbc.driver.OracleDriver");
                        Connection co=null;
                        co=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","marah");
                        Statement s1 = co.createStatement();
                        String req="select * from personne where mat="+mat+"";
                        ResultSet res=s1.executeQuery(req);
                        while(res.next())
                        {
                        %>
                        <html>
                            <head><title>Modification</title></head>
                            <body>
                            <center>
                                <h1>M O D I F I C A T I O N</h1>
                                <form action="update.jsp" method="post">
                                    
                                    Matricule
                                    <input type="text" name="mat" value="<%=res.getInt("mat")%>"><br><br>
                                    Nom
                                    <input type="text" name="nom" value="<%=res.getString("nom")%>"><br><br>
                                    S.Base
                                    <input type="text" name="sal" value="<%=res.getFloat("sal")%>"><br><br>
                                    Prime
                                    <input type="text" name="pr" value="<%=res.getFloat("pr")%>"><br><br><br><br>
                                    
                                    
                                    
                                    <input type="submit" value="modification">
                                </form>
                            </center>
                            </body>
                        </html>
                        <%
                            }
}
           catch(ClassNotFoundException e1)
{
out.println("err pilote");
}
catch(SQLException e2)
{
out.println("err connexion");
}                 


%>