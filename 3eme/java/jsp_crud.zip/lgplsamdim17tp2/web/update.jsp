<%@page import ="java.sql.*" %>

<%!int m;%>
<%!String n;%>
<%!float s;%>
<%!float p;%>

<%
    m=Integer.parseInt(request.getParameter("mat"));
    n=request.getParameter("nom");
    s=Float.valueOf(request.getParameter("sal"));

p=Float.valueOf(request.getParameter("pr"));    
  try
                    {
                        Class.forName("oracle.jdbc.driver.OracleDriver");
                        Connection co=null;
                        co=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","marah");
                        Statement s1 = co.createStatement();
                        String req="update personne set mat="+m+",nom='"+n+"',sal="+s+",pr="+p+" where mat="+m+"";
                        int resu=s1.executeUpdate(req);
                        
                        ServletContext ct = request.getServletContext();
                        RequestDispatcher dis=ct.getRequestDispatcher("/liste.jsp");
                        dis.forward(request,response);
                        

                    }
  
catch(ClassNotFoundException e1)
{
out.println("err pilote");
}
catch(SQLException e2)
{
out.println("err connexion");
}
                         

%>
