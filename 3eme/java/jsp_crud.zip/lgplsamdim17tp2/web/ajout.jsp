<%@page import ="java.sql.*" %>

<html>
    <head></head>
    <body>
    <center>
        <form action ="insert.jsp" method="post">
            Matricule
            <input type="text" name="m"><br><br>
             Nom
            <input type="text" name="n"><br><br>
             S.base
            <input type="text" name="s"><br><br>
             Prime
             <input type="text" name="p"><br><br><br>
             
            <input type="submit" value ="Insertion">
            
            
        </form>
    </center>
    </body>
</html>